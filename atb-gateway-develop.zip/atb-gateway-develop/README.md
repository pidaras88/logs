# Назначение

Микросервис предназначен для ретрансляции запросов клиентов из внешней сети на внутренние микросервисы Мобильного приложения. 

Схема взаимодействия микросервиса с другими компонентами системы изображена на следующем рисунке.   

![](doc/Компоненты.png)

# Схема базы данных
Для обработки данных в базе данных создается отдельная схема `wind-gateway` со следующими объектами:

* `t_gateway` - описание фильтров

Подробно о фильтрах см. в описании [Spring Cloud Gateway](https://docs.spring.io/spring-cloud-gateway/docs/current/reference/html/#gateway-starter)

Дополнительно предоставлены фильтры:

* `BlockUnauthorizedAccess` - отклоняет запросы, в которых отсутствует заголовок с сессионным токеном `x-auth-token`, 
либо сессионный токен принадлежит истекшей сессии. Еслм сессия действующая, то она продлевается поступишим запросом 
на заданный в настройках период времени. Фильтр сохраняет референс учетной записи сессии в атрибуте `accountId` запроса 
для других фильтров ниже по течению. 
 
* `AppendAccount` - добавляет в ретранслируемый запрос с типом `application/json` атрибут `accountId`, установленный  
авторизационным фильтром.

* `AppendAccountHeader` - добавляет в ретранслируемый запрос заголовок `account-id`, значение 
  для которого устанавливается авторизационным фильтром `BlockUnauthorizedAccess`.
  Для корректного заполнения аутентификация должна выполняться через API /atb-session/v1/login или atb-session/v2/login 

* `AppendRboHeader` - добавляет в ретранслируемый запрос заголовок `rbo-id`, значение
  для которого устанавливается авторизационным фильтром `BlockUnauthorizedAccess`.
  Для корректного заполнения аутентификация должна выполняться через API /atb-session/v1/iSimpleLogin

* `AppendClientIpHeader` - добавляет в ретранслируемый запрос заголовок `client-ip`, значение
  для которого берется из заголовка `X-Real-Ip` исходного запроса

# Требования

Для сборки и исполнения требуется:
 - JDK 17
 - Maven 3
 
# Настройки
Время жизни сессии задается конфигурационным параметром `atb.gateway.token.ttl.seconds`

# Локальный запуск проекта
* Запустить Docker контейнер с PostgreSQL  
```
docker run --name atb-gateway -p 5432:5432 -e POSTGRES_USER=wind_gateway -e POSTGRES_PASSWORD=wind_gateway -e POSTGRES_DB=yomi -d postgres:13.6-alpine
```
* Запустить Docker контейнер с Consul
```
docker run -d --name=atb-consul -p 8500:8500 consul
```
* Запустить Docker контейнер с Redis
```
docker run --name atb-redis -p 6379:6379 -d redis
```
* В своем локальном PostgreSQL раскатать таблицу `t_gateway`
```postgresql
create table t_gateway
(
    id        bigserial,
    c_gateway varchar(32) not null,
    c_route   jsonb       not null
);

comment on column t_gateway.id is 'Первичный ключ';
comment on column t_gateway.c_gateway is 'Принадлежит API gateway';
comment on column t_gateway.c_route is 'Конфигурация маршрута';

alter table t_gateway owner to wind_gateway;
```
* Запустить приложение с профилем `dev`
  
# Конфигурация

Конфигурация микросервиса хранится в разделе `wind-gateway` сервера кофигураций Consul, параметры присоединения к которому описаны в файле `boootstrap.properties`. 

Ниже представлена типовая конфигурация микросервиса.

```
#
# Application parameters
#
# Session token TTL (Time To Live)
atb.gateway.token.ttl.seconds=600

#
# Database
#
spring.datasource.url=jdbc:postgresql://test-swarm-db-1.tsb.kz:5433/yomi
spring.datasource.username=wind_gateway
spring.datasource.password=wind_gateway
spring.datasource.driver-class-name=org.postgresql.Driver

#
# Connection pool
#
spring.datasource.hikari.auto-commit=false
spring.datasource.hikari.pool-name=yomi

#
# String cloud
#
spring.cloud.features.enabled=false
spring.cloud.discovery.enabled=false

#
# String cloud gateway
#
spring.cloud.gateway.httpclient.wiretap=true

#
# Cloud bus
#
spring.rabbitmq.host=rabbit_mq
spring.rabbitmq.port:=5672
spring.rabbitmq.username=bus
spring.rabbitmq.password-bus

#
# Redis
#
spring.redis.client-type=lettuce
spring.redis.connect-timeout=6s
spring.redis.cluster.nodes=10.153.25.144:6379, 10.153.25.145:6379, 10.153.25.146:6379
spring.redis.cluster.max-redirects=3
spring.redis.password=.....

#
# Prometheus
#
management.endpoints.web.exposure.include=*
management.metrics.tags.application=${spring.application.name}
server.tomcat.mbeanregistry.enabled=true

#
# Metrics
#  
spring.cloud.gateway.metrics.enabled=true

management.metrics.enable.spring.cloud.gateway.requests=true
management.metrics.distribution.percentiles-histogram.spring.cloud.gateway.requests=true
management.metrics.distribution.percentiles.spring.cloud.gateway.requests=0.95

#
# Actuator
#
management.endpoint.gateway.enabled=true
management.endpoints.web.exposure.include=*

#
# Server
#
server.error.include-stacktrace=never

#
# Logging
#
logging.level.bank.atb=DEBUG
logging.level.org.springframework.cloud.gateway=INFO
logging.level.org.springframework.http.server.reactive=INFO
logging.level.reactor.netty=INFO
```
