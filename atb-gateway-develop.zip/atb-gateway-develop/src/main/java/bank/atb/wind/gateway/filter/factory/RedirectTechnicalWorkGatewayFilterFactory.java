package bank.atb.wind.gateway.filter.factory;

import bank.atb.wind.actuator.TechnicalWork;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;

import static org.springframework.cloud.gateway.support.GatewayToStringStyler.filterToStringCreator;

public class RedirectTechnicalWorkGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    public static final String COMMAND_SHOW_TECHNICAL_WORK_PAGE_MESSAGE = "{\"command\": \"SHOW_TECHNICAL_WORK_PAGE\", \"message\": \"Внимание!\\n\\nУважаемый клиент, сейчас проводятся технические работы. Примерное время завершения {{time}}. Приносим извинения за неудобства\", \"leftTimeInMills\" : \"%s\"}";

    @Override
    public GatewayFilter apply(Object config) {
        return new GatewayFilter() {
            @Override
            public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
                boolean activeTechnicalWork = TechnicalWork.getInstance().isActiveTechnicalWork();
                if (activeTechnicalWork) {
                    return handle(exchange);
                    // return chain.filter(exchange);
                }
                return chain.filter(exchange);
            }

            @Override
            public String toString() {
                return filterToStringCreator(RedirectTechnicalWorkGatewayFilterFactory.this).toString();
            }
        };
    }

    public Mono<Void> handle(ServerWebExchange exchange) {
        Long leftTimeInMills = TechnicalWork.getInstance().getLeftTimeInMills();
        String json = String.format(COMMAND_SHOW_TECHNICAL_WORK_PAGE_MESSAGE, leftTimeInMills);
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(bytes);
        exchange.getResponse().setStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
        exchange.getResponse().getHeaders().add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return exchange.getResponse().writeWith(Flux.just(buffer));
    }
}
