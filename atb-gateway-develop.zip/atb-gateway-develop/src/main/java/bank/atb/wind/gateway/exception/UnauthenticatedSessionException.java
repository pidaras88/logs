package bank.atb.wind.gateway.exception;

public class UnauthenticatedSessionException extends RuntimeException {

    public UnauthenticatedSessionException(String sessionId) {
        super(String.format("Сессия принадлежит неаутентифицированному устройству: sessionId [%s]", sessionId));
    }
}
