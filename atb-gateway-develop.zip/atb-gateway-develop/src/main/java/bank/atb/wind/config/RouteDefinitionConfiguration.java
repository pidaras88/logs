package bank.atb.wind.config;

import bank.atb.wind.gateway.support.JdbcRouteDefinitionLocator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.gateway.route.RouteDefinitionLocator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class RouteDefinitionConfiguration {

    @Bean
    @RefreshScope
    public RouteDefinitionLocator jdbcRouteDefinitionLocator(DataSource datasource, @Value("${gateway.code}") String code) {
        return new JdbcRouteDefinitionLocator(datasource, code);
    }

}
