package bank.atb.wind.gateway.support;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.FilterDefinition;
import org.springframework.cloud.gateway.handler.predicate.PredicateDefinition;
import org.springframework.cloud.gateway.route.RouteDefinition;
import org.springframework.cloud.gateway.route.RouteDefinitionLocator;
import reactor.core.publisher.Flux;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
public class JdbcRouteDefinitionLocator implements RouteDefinitionLocator {

    private final List<RouteDefinition> routes = new ArrayList<>();

    public JdbcRouteDefinitionLocator(DataSource datasource, String code) {
        load(datasource, code);
    }

    @Override
    public Flux<RouteDefinition> getRouteDefinitions() {
        log.info("Запрошена конфигурация маршрутов");

        return Flux.fromIterable(routes);
    }

    private void load(DataSource datasource, String code) {
        log.info("Загружается конфигурация маршрутов для '{}'", code);

        try (var connection = datasource.getConnection()) {
            try (var stm = connection.prepareStatement("select id, c_route from t_gateway where c_gateway = ?")) {
                stm.setString(1, code);

                try (var rs = stm.executeQuery()) {
                    ObjectMapper mapper = new ObjectMapper();

                    while (rs.next()) {
                        var spec = mapper.readValue(rs.getString(2), RouteSpec.class);

                        RouteDefinition definition = new RouteDefinition(rs.getString(1) + "=" + spec.uri());

                        for (var p : spec.predicates()) {
                            definition.getPredicates().add(new PredicateDefinition(p.name() + "=" + p.args()));
                        }

                        for (var p : spec.filters()) {
                            definition.getFilters().add(new FilterDefinition(p.name() + "=" + p.args()));
                        }

                        if (null != spec.advancedFilters()) {
                            for (var p : spec.advancedFilters()) {
                                FilterDefinition fd = new FilterDefinition();
                                fd.setName(p.name());
                                fd.setArgs(p.args());
                                definition.getFilters().add(fd);
                            }
                        }

                        if (null != spec.metatadata()) {
                            definition.setMetadata(spec.metatadata());
                        }

                        log(definition);
                        routes.add(definition);
                    }

                    log.info("Загрузка конфигурации завершена");
                }
            } finally {
                connection.commit();
            }
        } catch (Exception e) {
            log.error("Загрузка конфигурации не завершена ", e);
        }
    }

    private void log(RouteDefinition definition) {
        log.info("RouteDefinition: id = {}; uri = {}; predicates = {}; filters = {}; metadata = {}",
                definition.getId(), definition.getUri(),
                definition.getPredicates(), definition.getFilters(), definition.getMetadata());
    }

    public record Spec(
            String name,
            String args
    ) {
    }

    public record MapSpec(
            String name,
            Map<String, String> args
    ) {
    }

    public record RouteSpec(
            String uri,
            List<Spec> predicates,
            List<Spec> filters,
            List<MapSpec> advancedFilters,
            Map<String, Object> metatadata
    ) {
    }

}
