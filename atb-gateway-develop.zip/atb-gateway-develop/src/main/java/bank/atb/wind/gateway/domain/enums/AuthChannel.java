package bank.atb.wind.gateway.domain.enums;

public enum AuthChannel {
    WEB, MOBILE, I_SIMPLE
}
