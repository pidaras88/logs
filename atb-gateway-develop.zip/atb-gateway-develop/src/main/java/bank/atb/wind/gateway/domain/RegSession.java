package bank.atb.wind.gateway.domain;

import bank.atb.wind.gateway.domain.enums.RegStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class RegSession implements Serializable {

    @NotBlank
    private String sessionId;

    @NotNull
    private Long accountId;

    @NotBlank
    private String rboId;

    @NotBlank
    private String deviceId;

    @NotBlank
    private String login;

    @NotBlank
    private String clientIp;

    @NotBlank
    private String userAgent;

    @NotNull
    private RegStatus status;

    private Instant createdDateTime;

}
