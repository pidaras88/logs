package bank.atb.wind.gateway.filter.factory;

import bank.atb.wind.gateway.support.GatewayUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.filter.factory.rewrite.ModifyRequestBodyGatewayFilterFactory;
import org.springframework.http.MediaType;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.io.StringWriter;

import static org.springframework.cloud.gateway.support.GatewayToStringStyler.filterToStringCreator;

@Slf4j
public class AppendRboGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    private final ModifyRequestBodyGatewayFilterFactory modifyFactory;
    private final ObjectMapper mapper;

    public AppendRboGatewayFilterFactory(ModifyRequestBodyGatewayFilterFactory modifyFactory) {
        this.modifyFactory = modifyFactory;
        this.mapper = new ObjectMapper();
    }

    @Override
    public GatewayFilter apply(Object config) {
        return new GatewayFilter() {
            @Override
            public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
                // Подготовим фильтр, который добавит в запрос сведения об учетной записи.
                GatewayFilter modifyFilter = modifyFactory.apply(config ->
                        config.setRewriteFunction(String.class, String.class, (e, inputJson) -> {
                            try {
                                String accountId = exchange.getRequiredAttribute(GatewayUtils.ACCOUNT_ID_ATTR);

                                log.debug("{} accountId={}", exchange.getLogPrefix(), accountId);

                                if (!MediaType.APPLICATION_JSON.equals(exchange.getRequest().getHeaders().getContentType())) {
                                    throw new IllegalArgumentException("Ожидается ContentType=%s".formatted(MediaType.APPLICATION_JSON_VALUE));
                                }

                                return appendAccount(inputJson, accountId);
                            } catch (Exception exception) {
                                log.error(exchange.getLogPrefix(), exception);

                                return Mono.error(exception);
                            }
                        })
                );

                return modifyFilter.filter(exchange, chain);
            }

            @Override
            public String toString() {
                return filterToStringCreator(AppendRboGatewayFilterFactory.this).toString();
            }

            /**
             * Добавить в запрос сведения об учетной записи.
             *
             * @param inputJson Исходный JSON.
             * @param accountId Сведения об учетной записи.
             */
            private Publisher<String> appendAccount(String inputJson, String accountId) throws Exception {
                var stringWriter = new StringWriter();
                var rootNode = (ObjectNode) mapper.readTree(inputJson);

                rootNode.put("rboId", accountId);

                mapper.writeValue(stringWriter, rootNode);

                String outputJson = stringWriter.getBuffer().toString();

                return Mono.just(outputJson);
            }

        };
    }

}
