package bank.atb.wind.gateway.filter.global;

import bank.atb.wind.config.HeadersProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import static bank.atb.wind.gateway.support.GatewayUtils.ACCOUNT_ID_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.RBO_ID_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_ACCOUNT_ID_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_AUTH_TOKEN_HEADER_NAME;

@Component
@RequiredArgsConstructor
public class RemoveExcludedHeadersFilter implements GlobalFilter, Ordered {

    private final HeadersProperties headersProperties;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        return chain.filter(exchange).then(Mono.fromRunnable(() -> {
            // Получаем оригинальный ответ
            ServerHttpResponse response = exchange.getResponse();

            // Получаем заголовки ответа
            HttpHeaders headers = response.getHeaders();

            // Удаляем исключенные заголовки с данными о клиенте
            headers.remove(RBO_ID_HEADER_NAME);
            headers.remove(X_AUTH_TOKEN_HEADER_NAME);
            headers.remove(ACCOUNT_ID_HEADER_NAME);
            headers.remove(X_ACCOUNT_ID_HEADER_NAME);

            // Удаляем каждый исключенный заголовок из параметров
            headersProperties.getExcluded().forEach(headers::remove);
        }));
    }

    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }
}
