package bank.atb.wind.gateway.exception;

public class UserAgentNotMatchWebSessionException extends RuntimeException {

    public UserAgentNotMatchWebSessionException(String sessionId, String userAgent, String sessionUserAgent) {
        super(String.format("Юзер агент клиента из запроса не совпадает с данными из кэша сессии: sessionId [%s], " +
                "userAgent [%s], sessionUserAgent [%s]", sessionId, userAgent, sessionUserAgent));
    }
}
