package bank.atb.wind.gateway.exception;

public class InvalidSessionDataException extends RuntimeException {

    public InvalidSessionDataException(String message) {
        super(message);
    }
}
