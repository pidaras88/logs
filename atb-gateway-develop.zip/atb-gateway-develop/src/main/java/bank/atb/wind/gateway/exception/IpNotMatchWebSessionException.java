package bank.atb.wind.gateway.exception;

public class IpNotMatchWebSessionException extends RuntimeException {

    public IpNotMatchWebSessionException(String sessionId, String clientIp, String sessionClientIp) {
        super(String.format("Ип адрес клиента из запроса не совпадает с данными из кэша сессии: sessionId [%s], " +
                "clientIp [%s], sessionClientIp [%s]", sessionId, clientIp, sessionClientIp));
    }
}
