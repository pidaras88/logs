package bank.atb.wind.repository.impl;

import bank.atb.wind.gateway.domain.RegSession;
import bank.atb.wind.gateway.exception.InvalidSessionDataException;
import bank.atb.wind.repository.RegSessionRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Slf4j
@Service
public class RegSessionRepositoryImpl implements RegSessionRepository {

    @Value("${spring.redis.scan-enabled:false}")
    private boolean scanEnabled;
    @Value("${spring.redis.scan-options.count:100}")
    private long scanOptionsCount;
    private final RedisTemplate<String, RegSession> redisTemplate;

    @Autowired
    public RegSessionRepositoryImpl(@Qualifier("redisRegSessionTemplate") RedisTemplate<String, RegSession> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public RegSession findBySessionId(String sessionId) {
        Set<String> keys = getKeys(getPattern(sessionId));

        if (keys.size() != 1) {
            throw new InvalidSessionDataException(String.format("Ключ сессии регистрации [%s] не найден", sessionId));
        }

        String key = keys.iterator().next();
        RegSession session = redisTemplate.opsForValue().get(key);

        if (session == null) {
            throw new InvalidSessionDataException(String.format("Ключ сессии регистрации [%s] не найден", sessionId));
        }

        long expiration = redisTemplate.getExpire(key);

        if (expiration <= 0) {
            throw new InvalidSessionDataException(String.format("Сессия регистрации [%s] истекла", sessionId));
        }

        log.debug("Session expiration = {}, session: {}", expiration, session);

        return session;
    }

    private Set<String> getKeys(String pattern) {
        if (scanEnabled) {
            Set<String> keys = new HashSet<>();

            ScanOptions scanOptions = ScanOptions.scanOptions()
                    .match(pattern)
                    .count(scanOptionsCount)
                    .build();

            try (Cursor<String> cursor = redisTemplate.scan(scanOptions)) {
                cursor.forEachRemaining(keys::add);
            }

            return keys;
        }

        return redisTemplate.keys(pattern);
    }

    private String getPattern(String sessionId) {
        if (StringUtils.isBlank(sessionId)) {
            throw new IllegalArgumentException("sessionId не может быть пустым");
        }

        return String.format("account:*:regSession:%s", sessionId);
    }

}
