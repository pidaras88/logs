package bank.atb.wind.gateway.domain.enums;

public enum RegStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED
}
