package bank.atb.wind.gateway.filter.factory;

import bank.atb.wind.gateway.domain.RegSession;
import bank.atb.wind.gateway.domain.enums.RegStatus;
import bank.atb.wind.gateway.support.GatewayUtils;
import bank.atb.wind.repository.RegSessionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.RequestPath;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import static bank.atb.wind.gateway.support.GatewayUtils.ACCOUNT_ID_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.CHECKER_PATH_REGX;
import static bank.atb.wind.gateway.support.GatewayUtils.LOGIN_IB_PATH_REGX;
import static bank.atb.wind.gateway.support.GatewayUtils.ON_CHECKER_STATUS;
import static bank.atb.wind.gateway.support.GatewayUtils.ON_LOGIN_IB_STATUS;
import static bank.atb.wind.gateway.support.GatewayUtils.REG_SESSION_ID_COOKIE_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.USER_AGENT_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_ACCOUNT_ID_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_AUTH_TOKEN_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_REAL_IP_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_SOURCE_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_SOURCE_HEADER_VALUE_WEB;
import static org.springframework.cloud.gateway.support.GatewayToStringStyler.filterToStringCreator;

@Slf4j
@RequiredArgsConstructor
public class BlockNoRegSessionCookieGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    private final RegSessionRepository regSessionRepository;

    @Override
    public GatewayFilter apply(Object config) {
        return new GatewayFilter() {
            @Override
            public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
                HttpCookie cookie = exchange.getRequest().getCookies().getFirst(REG_SESSION_ID_COOKIE_NAME);

                if (cookie != null) {
                    String sessionId = cookie.getValue();

                    RegSession regSession;
                    try {
                        regSession = regSessionRepository.findBySessionId(sessionId);
                        String userAgent = exchange.getRequest().getHeaders().getFirst(USER_AGENT_HEADER_NAME);
                        String clientIp = exchange.getRequest().getHeaders().getFirst(X_REAL_IP_HEADER_NAME);
                        RequestPath path = exchange.getRequest().getPath();

                        //Сравниваем ип адрес из запроса с данными из кэша сессии
                        if (!regSession.getClientIp().equals(clientIp)) {
                            log.warn("Ип адрес клиента из запроса не совпадает с данными из кэша сессии регистрации: sessionId [{}], " +
                                    "clientIp [{}], sessionClientIp [{}]", sessionId, clientIp, regSession.getClientIp());
                            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);

                            return exchange.getResponse().setComplete();
                        }

                        //Сравниваем юзер агент из запроса с данными из кэша сессии
                        if (!regSession.getUserAgent().equals(userAgent)) {
                            log.warn("Юзер агент клиента из запроса не совпадает с данными из кэша сессии регистрации: sessionId [{}], " +
                                    "userAgent [{}], sessionUserAgent [{}]", sessionId, userAgent, regSession.getUserAgent());
                            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);

                            return exchange.getResponse().setComplete();
                        }

                        //Сравниваем статус сессии и путь
                        if (!isPathMatchStatus(path, regSession.getStatus())) {
                            log.warn("Статус сессии регистрации не соответствует пути запроса: regSessionId [{}], " +
                                    "status [{}], path [{}]", sessionId, regSession.getStatus(), path);
                            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);

                            return exchange.getResponse().setComplete();
                        }

                        // Сохраним референс учетной записи пользователя для дальнейшего использования.
                        exchange.getAttributes().put(GatewayUtils.ACCOUNT_ID_ATTR, regSession.getAccountId().toString());

                    } catch (RuntimeException e) {
                        log.warn("Ошибка при получении сессии регистрации из кэша: sessionId [{}]: {}", sessionId, e.toString());
                        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                        return exchange.getResponse().setComplete();
                    }

                    //Добавим заголовок X-Source
                    ServerHttpRequest request = exchange.getRequest()
                            .mutate()
                            .headers(httpHeaders -> {
                                httpHeaders.remove(X_AUTH_TOKEN_HEADER_NAME);
                                httpHeaders.remove(X_ACCOUNT_ID_HEADER_NAME);
                                httpHeaders.remove(ACCOUNT_ID_HEADER_NAME);
                                httpHeaders.add(X_SOURCE_HEADER_NAME, X_SOURCE_HEADER_VALUE_WEB);
                                httpHeaders.add(X_ACCOUNT_ID_HEADER_NAME, regSession.getRboId());
                            })
                            .build();

                    return chain.filter(exchange.mutate().request(request).build());
                } else {
                    log.warn("Куки регистрации отсутствуют");
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);

                    return exchange.getResponse().setComplete();
                }
            }

            @Override
            public String toString() {
                return filterToStringCreator(BlockNoRegSessionCookieGatewayFilterFactory.this).toString();
            }
        };
    }

    private boolean isPathMatchStatus(RequestPath path, RegStatus status) {
        return (path.toString().toLowerCase().contains(LOGIN_IB_PATH_REGX) && status.equals(ON_LOGIN_IB_STATUS)) ||
                (path.toString().toLowerCase().contains(CHECKER_PATH_REGX) && status.equals(ON_CHECKER_STATUS));
    }

}
