package bank.atb.wind.gateway.filter.global;

import io.micrometer.tracing.Tracer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.cloud.gateway.support.ServerWebExchangeUtils;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import su.atb.msa.core.protocols.MsaContextVariableName;
import su.atb.msa.core.protocols.MsaStandardHeadersRest;

import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class LoggingFilter implements GlobalFilter, Ordered {

    private final Tracer tracer;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        long startTime = System.currentTimeMillis();
        String traceId = getTraceId(exchange);
        String routeId = getRouteId(exchange);
        String callId = exchange.getRequest().getHeaders().getFirst(MsaStandardHeadersRest.CALL_ID);

        // Логируем запрос
        MDC.put(MsaContextVariableName.CALL_ID, callId);
        logRequest(exchange, traceId, routeId);

        return chain.filter(exchange)
                .doOnSuccess(v -> {
                    MDC.put(MsaContextVariableName.ACCOUNT_ID, exchange.getResponse().getHeaders().getFirst(MsaStandardHeadersRest.ACCOUNT_ID));
                    logResponse(exchange, traceId, routeId, startTime);
                })
                .doOnError(throwable -> {
                    MDC.put(MsaContextVariableName.ACCOUNT_ID, exchange.getResponse().getHeaders().getFirst(MsaStandardHeadersRest.ACCOUNT_ID));
                    log.error("Во время выполнения запроса произошла ошибка: TraceId [{}]: {}", traceId, throwable.toString());
                })
                .doFinally(s -> MDC.clear()); // Очищаем контекст
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE + 1;
    }

    private String getTraceId(ServerWebExchange exchange) {
        return Optional.ofNullable(tracer.currentSpan())
                .map(span -> span.context().traceId())
                .orElse(exchange.getLogPrefix());
    }

    private String getRouteId(ServerWebExchange exchange) {
        return Optional.ofNullable(exchange.getAttribute(ServerWebExchangeUtils.GATEWAY_ROUTE_ATTR))
                .map(Route.class::cast)
                .map(Route::getId)
                .orElse("unknown");
    }

    private void logRequest(ServerWebExchange exchange, String traceId, String routeId) {
        if (log.isDebugEnabled()) {
            log.info("""
                            ----- Request -----
                            TraceId      : {}
                            RouteId      : {}
                            RouteUri     : {}
                            Method       : {}
                            Headers      : {}
                            -------------------
                            """,
                    traceId,
                    routeId,
                    exchange.getRequest().getURI(),
                    exchange.getRequest().getMethod(),
                    exchange.getRequest().getHeaders());
        } else {
            log.info("""
                            ----- Request -----
                            TraceId      : {}
                            RouteId      : {}
                            RouteUri     : {}
                            Method       : {}
                            -------------------
                            """,
                    traceId,
                    routeId,
                    exchange.getRequest().getURI(),
                    exchange.getRequest().getMethod());
        }
    }

    private void logResponse(ServerWebExchange exchange, String traceId, String routeId, long startTime) {
        if (log.isDebugEnabled()) {
            log.info("""
                            ---- Response -----
                            TraceId      : {}
                            RouteId      : {}
                            RouteUri     : {}
                            StatusCode   : {}
                            Duration     : {} ms
                            Headers      : {}
                            -------------------
                            """,
                    traceId,
                    routeId,
                    exchange.getAttribute(ServerWebExchangeUtils.GATEWAY_REQUEST_URL_ATTR),
                    exchange.getResponse().getStatusCode(),
                    System.currentTimeMillis() - startTime,
                    exchange.getResponse().getHeaders());
        } else {
            log.info("""
                            ---- Response -----
                            TraceId      : {}
                            RouteId      : {}
                            RouteUri     : {}
                            StatusCode   : {}
                            -------------------
                            """,
                    traceId,
                    routeId,
                    exchange.getAttribute(ServerWebExchangeUtils.GATEWAY_REQUEST_URL_ATTR),
                    exchange.getResponse().getStatusCode());
        }
    }

}
