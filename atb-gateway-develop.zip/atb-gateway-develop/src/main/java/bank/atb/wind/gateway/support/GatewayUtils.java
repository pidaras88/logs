package bank.atb.wind.gateway.support;

import bank.atb.wind.gateway.domain.enums.RegStatus;

public class GatewayUtils {

    public static final String ACCOUNT_ID_ATTR = "accountId";

    public static final String X_AUTH_TOKEN_HEADER_NAME = "X-Auth-Token";
    public static final String ACCOUNT_ID_HEADER_NAME = "Account-Id";
    public static final String CLIENT_IP_HEADER_NAME = "Client-Ip";
    public static final String RBO_ID_HEADER_NAME = "Rbo-Id";
    public static final String X_REAL_IP_HEADER_NAME = "X-Real-Ip";
    public static final String X_CHANNEL_HEADER_NAME = "X-Channel";
    public static final String X_SOURCE_HEADER_NAME = "X-Source";
    public static final String X_CALL_ID_HEADER_NAME = "X-Call-Id";
    public static final String X_PROCESS_ID_HEADER_NAME = "X-Process-Id";
    public static final String X_ACCOUNT_ID_HEADER_NAME = "X-Account-Id";
    public static final String USER_AGENT_HEADER_NAME = "User-Agent";

    public static final String X_CHANNEL_HEADER_VALUE = "DBMF";
    public static final String X_SOURCE_HEADER_VALUE_MOBILE = "DBMA";
    public static final String X_SOURCE_HEADER_VALUE_WEB = "DBWA";

    public static final String REG_SESSION_ID_COOKIE_NAME = "REG-SESSION-ID";
    public static final String AUTH_SESSION_ID_COOKIE_NAME = "AUTH-SESSION-ID";

    public static final String LOGIN_IB_PATH_REGX = "/login-ib";
    public static final String CHECKER_PATH_REGX = "/checker/client";
    public static final RegStatus ON_LOGIN_IB_STATUS = RegStatus.COMPLETED;
    public static final RegStatus ON_CHECKER_STATUS = RegStatus.IN_PROGRESS;

}
