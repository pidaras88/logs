package bank.atb.wind.config;

import bank.atb.wind.gateway.domain.AuthSession;
import bank.atb.wind.gateway.domain.RegSession;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Slf4j
@Configuration
public class RedisConfig {

    @Value("${spring.redis.type}")
    private String type;
    private final RedisProperties properties;
    private final ObjectMapper objectMapper;

    public RedisConfig(@Qualifier("commonObjectMapper") ObjectMapper objectMapper, RedisProperties properties) {
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    /**
     * Check CLUSTER or SINGLE Redis type and setup properly LettuceConnectionFactory
     */
    @Bean
    LettuceConnectionFactory lettuceConnectionFactory() {

        if (type.equalsIgnoreCase("CLUSTER")) {

            log.info("Setup cluster Redis type");

            RedisClusterConfiguration clusterConfiguration = new RedisClusterConfiguration(properties.getCluster().getNodes());
            clusterConfiguration.setUsername(properties.getUsername());
            clusterConfiguration.setPassword(properties.getPassword());

            return new LettuceConnectionFactory(clusterConfiguration);

        } else {

            log.info("Setup single Redis type");

            RedisStandaloneConfiguration standaloneConfiguration = new RedisStandaloneConfiguration();
            standaloneConfiguration.setHostName(properties.getHost());
            standaloneConfiguration.setUsername(properties.getUsername());
            standaloneConfiguration.setPassword(properties.getPassword());

            return new LettuceConnectionFactory(standaloneConfiguration);

        }
    }

    @Bean
    public RedisTemplate<String, RegSession> redisRegSessionTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, RegSession> template = new RedisTemplate<>();
        Jackson2JsonRedisSerializer<RegSession> regSessionSerializer =
                new Jackson2JsonRedisSerializer<>(objectMapper, RegSession.class);
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(regSessionSerializer);
        template.setDefaultSerializer(regSessionSerializer);
        template.setConnectionFactory(redisConnectionFactory);
        return template;
    }

    @Bean
    public RedisTemplate<String, AuthSession> redisAuthSessionTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, AuthSession> template = new RedisTemplate<>();
        Jackson2JsonRedisSerializer<AuthSession> authSessionSerializer =
                new Jackson2JsonRedisSerializer<>(objectMapper, AuthSession.class);
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(authSessionSerializer);
        template.setDefaultSerializer(authSessionSerializer);
        template.setConnectionFactory(redisConnectionFactory);
        return template;
    }

}
