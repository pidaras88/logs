package bank.atb.wind.actuator;

import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

@Component
public final class TechnicalWork {

    private static final String TIME_PATTERN = "HH:mm";
    public static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern(TIME_PATTERN);

    private static TechnicalWork instance = getInstance();
    private boolean activeTechnicalWork;
    private LocalDateTime plannedCompletionTime;

    private TechnicalWork() {
        this.activeTechnicalWork = false;
    }

    public static TechnicalWork getInstance() {
        if (instance == null) {
            instance = new TechnicalWork();
        }
        return instance;
    }

    public boolean isActiveTechnicalWork() {
        return activeTechnicalWork;
    }

    public void enableTechnicalWork(LocalDateTime plannedCompletionTimeArg) {
        this.activeTechnicalWork = true;
        this.plannedCompletionTime = plannedCompletionTimeArg;
    }

    public void disableTechnicalWork() {
        this.activeTechnicalWork = false;
        this.plannedCompletionTime = LocalDateTime.now();
    }

    public String getPlannedCompletionTime() {
        return plannedCompletionTime.format(TIME_FORMATTER);
    }

    public Long getLeftTimeInMills() {
        if (plannedCompletionTime.isBefore(LocalDateTime.now())) {
            return 0L;
        } else {
            return ChronoUnit.MILLIS.between(LocalDateTime.now(), plannedCompletionTime);
        }
    }

}
