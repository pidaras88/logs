package bank.atb.wind;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import io.netty.resolver.DefaultAddressResolverGroup;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Hooks;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

@SpringBootApplication
@ConfigurationPropertiesScan
public class Application {

    @Bean
    public WebClient webClient(@Value("${atb.gateway.webclient.timeout.read}") Integer readTimeout,
                               @Value("${atb.gateway.webclient.timeout.write}") Integer writeTimeout,
                               @Value("${atb.gateway.webclient.timeout.connection}") Integer timeoutConnection,
                               @Value("${atb.gateway.webclient.connection.pool-name}") String connectionPoolName,
                               @Value("${atb.gateway.webclient.max-connections}") Integer maxConnections,
                               @Value("${atb.gateway.webclient.pending-acquire-max-count}") Integer pendingAcquireMaxCount,
                               @Value("${atb.gateway.webclient.resolver-enabled:false}") Boolean resolverEnabled) {

        ConnectionProvider connectionProvider = ConnectionProvider
                .builder(connectionPoolName)
                .maxConnections(maxConnections)
                .pendingAcquireMaxCount(pendingAcquireMaxCount)
                .pendingAcquireTimeout(Duration.ofMillis(timeoutConnection))
                .build();

        HttpClient httpClient = HttpClient.create(connectionProvider)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, timeoutConnection)
                .doOnConnected(connection -> {
                    connection.addHandlerLast(new ReadTimeoutHandler(readTimeout, TimeUnit.MILLISECONDS));
                    connection.addHandlerLast(new WriteTimeoutHandler(writeTimeout, TimeUnit.MILLISECONDS));
                });

        if (resolverEnabled) {
            httpClient.resolver(DefaultAddressResolverGroup.INSTANCE);
        }

        final ExchangeStrategies exchangeStrategies = ExchangeStrategies.builder()
                .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(-1)) // to unlimited memory size
                .build();
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .exchangeStrategies(exchangeStrategies)
                .build();
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        Hooks.enableAutomaticContextPropagation();
    }

}
