package bank.atb.wind.gateway.filter.global;

import bank.atb.wind.gateway.support.GatewayUtils;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Component
public class AddHeaderChannelFilter implements GlobalFilter, Ordered {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest mutateRequest = exchange.getRequest()
                .mutate()
                .header(GatewayUtils.X_CHANNEL_HEADER_NAME, GatewayUtils.X_CHANNEL_HEADER_VALUE)
                .build();

        return chain.filter(exchange.mutate().request(mutateRequest).build());
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE;
    }
}
