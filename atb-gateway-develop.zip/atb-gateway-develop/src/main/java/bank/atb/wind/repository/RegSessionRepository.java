package bank.atb.wind.repository;

import bank.atb.wind.gateway.domain.RegSession;

public interface RegSessionRepository {

    RegSession findBySessionId(String sessionId);

}
