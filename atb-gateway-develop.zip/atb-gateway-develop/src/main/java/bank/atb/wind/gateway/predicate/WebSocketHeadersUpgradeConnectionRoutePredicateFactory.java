package bank.atb.wind.gateway.predicate;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.handler.predicate.AbstractRoutePredicateFactory;
import org.springframework.cloud.gateway.handler.predicate.GatewayPredicate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.server.ServerWebExchange;

import java.util.function.Predicate;

@Component
@Slf4j
public class WebSocketHeadersUpgradeConnectionRoutePredicateFactory extends
        AbstractRoutePredicateFactory<WebSocketHeadersUpgradeConnectionRoutePredicateFactory.Config> {

    public WebSocketHeadersUpgradeConnectionRoutePredicateFactory() {
        super(WebSocketHeadersUpgradeConnectionRoutePredicateFactory.Config.class);
    }

    @Override
    public Predicate<ServerWebExchange> apply(Config config) {
//        log.debug("New WEBSOCKET connection is enabled: {}", config.enabled);
        return (GatewayPredicate) exchange -> {
//            if (config.enabled) {
//                if (isWebSocketUpgradeRequest(exchange)) {
            log.debug("WEBSOCKET UPGRADE: {}", config.enabled);
            ServerHttpRequest request = exchange.getRequest();
            HttpHeaders headers = request.getHeaders();

            request.mutate().headers(httpHeaders -> {
                httpHeaders.setUpgrade("websocket");
                httpHeaders.setConnection("Upgrade");
            });

            log.debug("WEBSOCKET REQUEST HEADERS: {}", request.getHeaders());

            exchange.getResponse().getHeaders().setUpgrade("websocket");
            exchange.getResponse().getHeaders().setConnection("Upgrade");

            log.debug("WEBSOCKET RESPONSE HEADERS: {}", exchange.getResponse().getHeaders());
            return true;
//                }
//            }
//            return false;
        };
    }

    private boolean isWebSocketUpgradeRequest(ServerWebExchange exchange) {
        log.debug("CHECK IS WEBSOCKET UPGRADE.");
        return exchange.getRequest().getHeaders().getUpgrade() != null &&
                exchange.getRequest().getHeaders().getUpgrade().contains("websocket");
    }

    @Validated
    public static class Config {
        boolean enabled = true;
    }
}
