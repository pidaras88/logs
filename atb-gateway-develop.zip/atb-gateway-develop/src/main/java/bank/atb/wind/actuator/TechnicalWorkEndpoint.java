package bank.atb.wind.actuator;

import org.springframework.boot.actuate.endpoint.annotation.DeleteOperation;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;

import java.time.LocalDateTime;

@Endpoint(id = "technical-work")
public class TechnicalWorkEndpoint {

    private final TechnicalWork technicalWork;

    public TechnicalWorkEndpoint(TechnicalWork technicalWork) {
        this.technicalWork = technicalWork;
    }

    @ReadOperation
    public String getInfoAboutTechnicalWork() {
        TechnicalWork work = TechnicalWork.getInstance();
        String answer;
        if (work.isActiveTechnicalWork()) {
            answer = "Technical work is active, planned completion time ~ " + work.getPlannedCompletionTime();
        } else {
            answer = "Technical work isn't active";
        }
        return answer;
    }

    @WriteOperation
    public String enableTechnicalWork(@Selector Long durationInMinutes) {
        System.out.println("call enableTechnicalWork");
        technicalWork.enableTechnicalWork(LocalDateTime.now().plusMinutes(durationInMinutes));
        return "enabled";
    }

    @DeleteOperation
    public String disableTechnicalWork() {
        System.out.println("call disableTechnicalWork");
        technicalWork.disableTechnicalWork();
        return "disabled";
    }

}
