package bank.atb.wind.repository.impl;

import bank.atb.wind.gateway.domain.AuthSession;
import bank.atb.wind.gateway.exception.InvalidSessionDataException;
import bank.atb.wind.repository.AuthSessionRepository;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class AuthSessionRepositoryImpl implements AuthSessionRepository {

    @Value("${atb.gateway.token.ttl.seconds:3600}")
    private long sessionTtl;
    @Value("${spring.redis.scan-enabled:false}")
    private boolean scanEnabled;
    @Value("${spring.redis.scan-options.count:100}")
    private long scanOptionsCount;
    private final RedisTemplate<String, AuthSession> redisTemplate;

    @Autowired
    public AuthSessionRepositoryImpl(@Qualifier("redisAuthSessionTemplate") RedisTemplate<String, AuthSession> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @PostConstruct
    private void init() {
        log.info("Session token TTL = {} seconds", sessionTtl);
    }

    @Override
    public AuthSession findBySessionId(String sessionId) {

        Set<String> keys = getKeys(getPattern(sessionId));

        if (keys.size() != 1) {
            throw new InvalidSessionDataException(String.format("Ключ сессии авторизации [%s] не найден", sessionId));
        }

        String key = keys.iterator().next();
        AuthSession session = redisTemplate.opsForValue().get(key);

        if (session == null) {
            throw new InvalidSessionDataException(String.format("Ключ сессии авторизации [%s] не найден", sessionId));
        }

        long expiration = redisTemplate.getExpire(key);

        if (expiration <= 0) {
            throw new InvalidSessionDataException(String.format("Сессия авторизации [%s] истекла", sessionId));
        }

        log.debug("Session expiration = {}, session: {}", expiration, session);

        return session;
    }

    @Override
    public Mono<Void> extendTimeout(AuthSession session) {
        return Mono.fromRunnable(() -> {
            if (session != null) {
                String key = getKey(session.getAccountId(), session.getSessionId());
                log.debug("Session [{}] timeout is extended", key);
                redisTemplate.expire(key, sessionTtl, TimeUnit.SECONDS);
            } else {
                log.warn("Не смогли продлить сессию");
            }
        });
    }

    @Override
    public void deleteBySessionId(String sessionId, Long accountId) {
        String key = getKey(accountId, sessionId);
        log.debug("Попытка удаления сессии аутентификации: sessionId [{}]", key);

        Boolean result = redisTemplate.delete(key);

        if (result) {
            log.info("Сессия аутентификации была удалена: sessionId [{}]", key);
        } else {
            log.warn("Не смогли удалить сессию аутентификации: sessionId [{}]", key);
        }
    }

    private Set<String> getKeys(String pattern) {
        if (scanEnabled) {
            Set<String> keys = new HashSet<>();

            ScanOptions scanOptions = ScanOptions.scanOptions()
                    .match(pattern)
                    .count(scanOptionsCount)
                    .build();

            try (Cursor<String> cursor = redisTemplate.scan(scanOptions)) {
                cursor.forEachRemaining(keys::add);
            }

            return keys;
        }

        return redisTemplate.keys(pattern);
    }

    private String getKey(Long accountId, String sessionId) {
        if (null == accountId) {
            throw new IllegalArgumentException("accountId не может быть null");
        }

        validateNotBlank(sessionId);

        return String.format("account:%d:session:%s", accountId, sessionId);
    }

    private String getPattern(String sessionId) {
        validateNotBlank(sessionId);

        return String.format("account:*:session:%s", sessionId);
    }

    private void validateNotBlank(String value) {
        if (StringUtils.isBlank(value)) {
            throw new IllegalArgumentException("sessionId не может быть пустым");
        }
    }

}
