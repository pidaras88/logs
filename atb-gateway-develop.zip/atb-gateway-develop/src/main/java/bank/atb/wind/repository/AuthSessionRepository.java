package bank.atb.wind.repository;

import bank.atb.wind.gateway.domain.AuthSession;
import reactor.core.publisher.Mono;

public interface AuthSessionRepository {

    /**
     * Получить сессию аутентификации по ид
     *
     * @param sessionId Ид сессии аутентификации
     */
    AuthSession findBySessionId(String sessionId);

    /**
     * Сохранить сессию аутентификации с заданным временем жизни
     *
     * @param session Сессия аутентификации
     */
    Mono<Void> extendTimeout(AuthSession session);

    /**
     * Удалить сессию аутентификации не дожидаясь ее истечения
     *
     * @param sessionId Ид сессии аутентификации
     * @param accountId Ид аккаунта пользователя в ДБО
     */
    void deleteBySessionId(String sessionId, Long accountId);

}
