package bank.atb.wind.gateway.filter.factory;

import bank.atb.wind.gateway.domain.AuthSession;
import bank.atb.wind.gateway.domain.enums.AuthChannel;
import bank.atb.wind.gateway.exception.IpNotMatchWebSessionException;
import bank.atb.wind.gateway.exception.UnauthenticatedSessionException;
import bank.atb.wind.gateway.exception.UserAgentNotMatchWebSessionException;
import bank.atb.wind.gateway.support.GatewayUtils;
import bank.atb.wind.repository.AuthSessionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.List;

import static bank.atb.wind.gateway.support.GatewayUtils.ACCOUNT_ID_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.AUTH_SESSION_ID_COOKIE_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.USER_AGENT_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_ACCOUNT_ID_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_AUTH_TOKEN_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_REAL_IP_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_SOURCE_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_SOURCE_HEADER_VALUE_MOBILE;
import static bank.atb.wind.gateway.support.GatewayUtils.X_SOURCE_HEADER_VALUE_WEB;
import static org.springframework.cloud.gateway.support.GatewayToStringStyler.filterToStringCreator;

@Slf4j
@RequiredArgsConstructor
public class BlockUnauthorizedAccessGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    @Value("${atb.gateway.domain}")
    private String domain;
    @Value("${atb.gateway.cookie.ttl.seconds:300}")
    private long cookieTtlSeconds;
    private final AuthSessionRepository authSessionRepository;

    @Override
    public GatewayFilter apply(Object config) {
        return new GatewayFilter() {
            @Override
            public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
                HttpCookie cookie = exchange.getRequest().getCookies().getFirst(AUTH_SESSION_ID_COOKIE_NAME);
                HttpHeaders headers = exchange.getRequest().getHeaders();

                //Если есть куки - получаем ид сессии из куки
                String sessionId = cookie != null ? cookie.getValue() : headers.getFirst(X_AUTH_TOKEN_HEADER_NAME);

                try {
                    //В фазе начала обработки запроса клиента поверяем наличие активной сессии
                    AuthSession session = authSessionRepository.findBySessionId(sessionId);

                    //Если регистрация не завершена - отказ в доступе
                    if (!session.getIsDeviceAuthenticated() || StringUtils.isBlank(session.getRboId())) {
                        throw new UnauthenticatedSessionException(sessionId);
                    }

                    if (AuthChannel.WEB.equals(session.getAuthChannel())) {
                        //Получаем ип клиента и юзер агента
                        String clientIp = headers.getFirst(X_REAL_IP_HEADER_NAME);
                        String userAgent = headers.getFirst(USER_AGENT_HEADER_NAME);

                        //Сравниваем ип адрес из запроса с данными из кэша сессии
                        if (StringUtils.isBlank(clientIp) || !clientIp.equals(session.getClientIp())) {
                            authSessionRepository.deleteBySessionId(sessionId, session.getAccountId());
                            throw new IpNotMatchWebSessionException(sessionId, clientIp, session.getClientIp());
                        }

                        //Сравниваем юзер агент из запроса с данными из кэша сессии
                        if (StringUtils.isBlank(userAgent) || !userAgent.equals(session.getUserAgent())) {
                            authSessionRepository.deleteBySessionId(sessionId, session.getAccountId());
                            throw new UserAgentNotMatchWebSessionException(sessionId, userAgent, session.getUserAgent());
                        }
                    }

                    //Удалим авторизационный токен и добавим заголовок, содержащий RBO ID пользователя
                    ServerHttpRequest request = exchange.getRequest()
                            .mutate()
                            .headers(httpHeaders -> {
                                httpHeaders.remove(X_AUTH_TOKEN_HEADER_NAME);
                                httpHeaders.remove(X_ACCOUNT_ID_HEADER_NAME);
                                httpHeaders.remove(ACCOUNT_ID_HEADER_NAME);
                                httpHeaders.add(X_ACCOUNT_ID_HEADER_NAME, session.getRboId());
                                if (session.getAuthChannel().equals(AuthChannel.WEB)) {
                                    httpHeaders.add(X_SOURCE_HEADER_NAME, X_SOURCE_HEADER_VALUE_WEB);
                                }
                                if (session.getAuthChannel().equals(AuthChannel.MOBILE) ||
                                        session.getAuthChannel().equals(AuthChannel.I_SIMPLE)) {
                                    httpHeaders.add(X_SOURCE_HEADER_NAME, X_SOURCE_HEADER_VALUE_MOBILE);
                                }
                            })
                            .build();

                    //Сохраним референс учетной записи пользователя для дальнейшего использования.
                    exchange.getAttributes().put(GatewayUtils.ACCOUNT_ID_ATTR, session.getAccountId().toString());

                    //В фазе завершения обработки запроса клиента продлеваем сессию
                    return chain
                            .filter(exchange.mutate().request(request).build())
                            .then(authSessionRepository.extendTimeout(session))
                            .then(extendCookie(exchange, cookie));
                } catch (RuntimeException e) {
                    log.warn("Ошибка при получении сессии из кэша: sessionId [{}]: {}}", sessionId, e.toString());
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                    return exchange.getResponse().setComplete();
                }
            }

            @Override
            public String toString() {
                return filterToStringCreator(BlockUnauthorizedAccessGatewayFilterFactory.this).toString();
            }
        };
    }

    //Продлеваем куки, если есть и если не установлено другое значение
    private Mono<Void> extendCookie(ServerWebExchange exchange, HttpCookie cookie) {
        return Mono.fromRunnable(() -> {
            if (cookie == null) {
                return;
            }

            List<String> cookieValues = exchange.getResponse().getHeaders().get("Set-Cookie");

            if (cookieValues != null) {
                for (String cookieValue : cookieValues) {
                    if (cookieValue != null && cookieValue.contains(AUTH_SESSION_ID_COOKIE_NAME)) {
                        return;
                    }
                }
            }

            ResponseCookie extendCookie = ResponseCookie.from(cookie.getName(), cookie.getValue())
                    .maxAge(cookieTtlSeconds)
                    .domain(domain)
                    .httpOnly(true)
                    .secure(true)
                    .path("/")
                    .build();
            exchange.getResponse().addCookie(extendCookie);
        });
    }

}
