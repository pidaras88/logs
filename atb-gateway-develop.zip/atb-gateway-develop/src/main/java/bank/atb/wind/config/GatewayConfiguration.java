package bank.atb.wind.config;

import bank.atb.wind.gateway.filter.factory.AppendAccountGatewayFilterFactory;
import bank.atb.wind.gateway.filter.factory.AppendAccountHeaderGatewayFilterFactory;
import bank.atb.wind.gateway.filter.factory.AppendClientIpHeaderGatewayFilterFactory;
import bank.atb.wind.gateway.filter.factory.AppendRboGatewayFilterFactory;
import bank.atb.wind.gateway.filter.factory.AppendRboHeaderGatewayFilterFactory;
import bank.atb.wind.gateway.filter.factory.AppendTypeAppGatewayFilterFactory;
import bank.atb.wind.gateway.filter.factory.BlockNoRegSessionCookieGatewayFilterFactory;
import bank.atb.wind.gateway.filter.factory.BlockNoSessionAccessGatewayFilterFactory;
import bank.atb.wind.gateway.filter.factory.BlockUnauthorizedAccessGatewayFilterFactory;
import bank.atb.wind.gateway.filter.factory.RedirectTechnicalWorkGatewayFilterFactory;
import bank.atb.wind.repository.AuthSessionRepository;
import bank.atb.wind.repository.RegSessionRepository;
import org.springframework.cloud.gateway.filter.factory.SetRequestHeaderGatewayFilterFactory;
import org.springframework.cloud.gateway.filter.factory.rewrite.ModifyRequestBodyGatewayFilterFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
public class GatewayConfiguration {

    @Bean
    public RedirectTechnicalWorkGatewayFilterFactory redirectTechnicalWorkGatewayFilterFactory() {
        return new RedirectTechnicalWorkGatewayFilterFactory();
    }

    @Bean
    public AppendTypeAppGatewayFilterFactory appendTypeAppGatewayFilterFactory(ModifyRequestBodyGatewayFilterFactory modifyFactory) {
        return new AppendTypeAppGatewayFilterFactory(modifyFactory);
    }

    @Bean
    public AppendAccountGatewayFilterFactory appendAccountGatewayFilterFactory(ModifyRequestBodyGatewayFilterFactory modifyFactory) {
        return new AppendAccountGatewayFilterFactory(modifyFactory);
    }

    @Bean
    public AppendAccountHeaderGatewayFilterFactory appendAccountHeaderGatewayFilterFactory(SetRequestHeaderGatewayFilterFactory setRequestHeaderFactory) {
        return new AppendAccountHeaderGatewayFilterFactory(setRequestHeaderFactory);
    }

    @Bean
    public AppendRboHeaderGatewayFilterFactory appendRboHeaderGatewayFilterFactory(SetRequestHeaderGatewayFilterFactory setRequestHeaderFactory) {
        return new AppendRboHeaderGatewayFilterFactory(setRequestHeaderFactory);
    }

    @Bean
    public AppendClientIpHeaderGatewayFilterFactory appendClientIpHeaderGatewayFilterFactory(SetRequestHeaderGatewayFilterFactory setRequestHeaderFactory) {
        return new AppendClientIpHeaderGatewayFilterFactory(setRequestHeaderFactory);
    }

    @Bean
    public AppendRboGatewayFilterFactory appendRboGatewayFilterFactory(ModifyRequestBodyGatewayFilterFactory modifyFactory) {
        return new AppendRboGatewayFilterFactory(modifyFactory);
    }

    @Bean
    public BlockUnauthorizedAccessGatewayFilterFactory blockUnauthorizedAccessGatewayFilterFactory(AuthSessionRepository authSessionRepository) {
        return new BlockUnauthorizedAccessGatewayFilterFactory(authSessionRepository);
    }

    @Bean
    public BlockNoSessionAccessGatewayFilterFactory blockNoSessionAccessGatewayFilterFactory(AuthSessionRepository authSessionRepository) {
        return new BlockNoSessionAccessGatewayFilterFactory(authSessionRepository);
    }

    @Bean
    public BlockNoRegSessionCookieGatewayFilterFactory blockNoRegSessionCookieGatewayFilterFactory(RegSessionRepository regSessionRepository) {
        return new BlockNoRegSessionCookieGatewayFilterFactory(regSessionRepository);
    }

}