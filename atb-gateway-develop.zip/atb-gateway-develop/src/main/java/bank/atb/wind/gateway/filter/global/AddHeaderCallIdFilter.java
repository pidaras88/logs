package bank.atb.wind.gateway.filter.global;

import bank.atb.wind.gateway.support.GatewayUtils;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Component
public class AddHeaderCallIdFilter implements GlobalFilter, Ordered {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        if (!isContainsHeader(exchange)) {
            String uuid = UUID.randomUUID().toString();
            ServerHttpRequest mutateRequest = exchange.getRequest()
                    .mutate()
                    .header(GatewayUtils.X_CALL_ID_HEADER_NAME, uuid)
                    .build();
            return chain.filter(exchange.mutate().request(mutateRequest).build());
        }

        return chain.filter(exchange);
    }

    private boolean isContainsHeader(ServerWebExchange exchange) {
        return exchange.getRequest().getHeaders().containsKey(GatewayUtils.X_CALL_ID_HEADER_NAME);
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE;
    }
}
