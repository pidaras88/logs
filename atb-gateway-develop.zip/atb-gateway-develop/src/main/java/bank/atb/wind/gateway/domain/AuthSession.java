package bank.atb.wind.gateway.domain;

import bank.atb.wind.gateway.domain.enums.AuthChannel;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class AuthSession {

    @NotBlank
    private String sessionId;

    @NotNull
    private Long accountId;

    @NotBlank
    private String deviceId;

    @NotBlank
    private String login;

    @NotNull
    private AuthChannel authChannel;

    @Builder.Default
    private Boolean isDeviceAuthenticated = false;

    private String rboId;
    private String clientIp;
    private String userAgent;
    private Instant createdDateTime;

}
