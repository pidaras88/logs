package bank.atb.wind.gateway.filter.factory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.filter.factory.rewrite.ModifyRequestBodyGatewayFilterFactory;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.http.MediaType;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.io.StringWriter;

@Slf4j
public class AppendTypeAppGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    private static final String TYPE_APP_KEY = "nameAppType";

    private final ModifyRequestBodyGatewayFilterFactory modifyFactory;
    private final ObjectMapper mapper;

    public AppendTypeAppGatewayFilterFactory(ModifyRequestBodyGatewayFilterFactory modifyFactory) {
        this.modifyFactory = modifyFactory;
        this.mapper = new ObjectMapper();
    }


    @Override
    public GatewayFilter apply(Object config) {
        return new GatewayFilter() {
            @Override
            public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
                // Подготовим фильтр, который добавит в запрос сведения о типе мобильного приложения.
                GatewayFilter modifyFilter = modifyFactory.apply(config ->
                        config.setRewriteFunction(String.class, String.class, (e, inputJson) -> {
                            try {
                                var route = (Route) exchange.getAttribute("org.springframework.cloud.gateway.support.ServerWebExchangeUtils.gatewayRoute");

                                var nameTypeApp = String.valueOf(route.getMetadata().get(TYPE_APP_KEY));
                                log.debug("{} add type app={}", exchange.getLogPrefix(), nameTypeApp);

                                if (!MediaType.APPLICATION_JSON.equals(exchange.getRequest().getHeaders().getContentType())) {
                                    throw new IllegalArgumentException("Ожидается ContentType=%s".formatted(MediaType.APPLICATION_JSON_VALUE));
                                }

                                return appendTypeApp(inputJson, nameTypeApp);
                            } catch (Exception exception) {
                                log.error(exchange.getLogPrefix(), exception);

                                return Mono.error(exception);
                            }
                        })
                );

                return modifyFilter.filter(exchange, chain);
            }

            /**
             * Добавить в запрос сведения о типе мобильного приложения.
             *
             * @param inputJson Исходный JSON.
             * @param typeApp Сведения о типе мобильного приложения.
             */
            private Publisher<String> appendTypeApp(String inputJson, String typeApp) throws Exception {
                var stringWriter = new StringWriter();
                var rootNode = (ObjectNode) mapper.readTree(inputJson);

                rootNode.put("typeApp", typeApp);

                mapper.writeValue(stringWriter, rootNode);

                String outputJson = stringWriter.getBuffer().toString();

                return Mono.just(outputJson);
            }
        };
    }
}
