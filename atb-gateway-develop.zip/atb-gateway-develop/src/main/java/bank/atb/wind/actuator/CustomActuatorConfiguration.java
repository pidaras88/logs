package bank.atb.wind.actuator;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CustomActuatorConfiguration {

    @Bean
    public TechnicalWorkEndpoint technicalWorkEndpoint() {
        return new TechnicalWorkEndpoint(TechnicalWork.getInstance());
    }

}
