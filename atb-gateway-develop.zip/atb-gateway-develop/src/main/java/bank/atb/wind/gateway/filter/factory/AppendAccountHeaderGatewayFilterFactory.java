package bank.atb.wind.gateway.filter.factory;

import bank.atb.wind.gateway.support.GatewayUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.filter.factory.AbstractNameValueGatewayFilterFactory.NameValueConfig;
import org.springframework.cloud.gateway.filter.factory.SetRequestHeaderGatewayFilterFactory;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import static org.springframework.cloud.gateway.support.GatewayToStringStyler.filterToStringCreator;

@Slf4j
public class AppendAccountHeaderGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    private final SetRequestHeaderGatewayFilterFactory setRequestHeaderGatewayFilterFactory;

    public AppendAccountHeaderGatewayFilterFactory(
            SetRequestHeaderGatewayFilterFactory setRequestHeaderGatewayFilterFactory) {
        this.setRequestHeaderGatewayFilterFactory = setRequestHeaderGatewayFilterFactory;
    }

    @Override
    public GatewayFilter apply(Object config) {
        return new GatewayFilter() {
            @Override
            public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

                NameValueConfig nameValueConfig = new NameValueConfig();
                nameValueConfig.setName(GatewayUtils.ACCOUNT_ID_HEADER_NAME);
                nameValueConfig.setValue(exchange.getRequiredAttribute(GatewayUtils.ACCOUNT_ID_ATTR));

                GatewayFilter setHeaderFilter = setRequestHeaderGatewayFilterFactory.apply(nameValueConfig);
                return setHeaderFilter.filter(exchange, chain);
            }

            @Override
            public String toString() {
                return filterToStringCreator(AppendAccountHeaderGatewayFilterFactory.this).toString();
            }
        };
    }

}
