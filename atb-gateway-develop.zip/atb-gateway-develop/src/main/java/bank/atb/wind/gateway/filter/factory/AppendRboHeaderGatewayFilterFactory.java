package bank.atb.wind.gateway.filter.factory;

import bank.atb.wind.gateway.support.GatewayUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.filter.factory.AbstractNameValueGatewayFilterFactory.NameValueConfig;
import org.springframework.cloud.gateway.filter.factory.SetRequestHeaderGatewayFilterFactory;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import static org.springframework.cloud.gateway.support.GatewayToStringStyler.filterToStringCreator;

@Slf4j
public class AppendRboHeaderGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    private final SetRequestHeaderGatewayFilterFactory setRequestHeaderGatewayFilterFactory;

    public AppendRboHeaderGatewayFilterFactory(
            SetRequestHeaderGatewayFilterFactory setRequestHeaderGatewayFilterFactory) {
        this.setRequestHeaderGatewayFilterFactory = setRequestHeaderGatewayFilterFactory;
    }

    /**
     * @implNote значение для rbo-id заголовка нужно действительно сейчас брать
     * из GatewayUtils.ACCOUNT_ID_ATRR - тут нет ошибки. Это необходимо потому что
     * в момент создания сессии iSimple в кэш сессии в свойство GatewayUtils.ACCOUNT_ID_ATRR
     * записывается именно rboId. Почему не сделали для хранения rboId отдельное свойство
     * с отдельным именованием, например GatewayUtils.RBO_ID_ATRR - я не знаю,
     * видимо так "сложилось исторически"
     */
    @Override
    public GatewayFilter apply(Object config) {
        return new GatewayFilter() {
            @Override
            public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

                NameValueConfig nameValueConfig = new NameValueConfig();
                nameValueConfig.setName(GatewayUtils.RBO_ID_HEADER_NAME);
                nameValueConfig.setValue(exchange.getRequiredAttribute(GatewayUtils.ACCOUNT_ID_ATTR));

                GatewayFilter setHeaderFilter = setRequestHeaderGatewayFilterFactory.apply(nameValueConfig);
                return setHeaderFilter.filter(exchange, chain);
            }

            @Override
            public String toString() {
                return filterToStringCreator(AppendRboHeaderGatewayFilterFactory.this).toString();
            }
        };
    }

}
