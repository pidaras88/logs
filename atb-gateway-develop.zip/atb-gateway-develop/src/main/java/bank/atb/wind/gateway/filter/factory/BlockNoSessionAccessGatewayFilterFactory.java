package bank.atb.wind.gateway.filter.factory;

import bank.atb.wind.gateway.domain.AuthSession;
import bank.atb.wind.gateway.domain.enums.AuthChannel;
import bank.atb.wind.gateway.support.GatewayUtils;
import bank.atb.wind.repository.AuthSessionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import static bank.atb.wind.gateway.support.GatewayUtils.ACCOUNT_ID_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_ACCOUNT_ID_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_AUTH_TOKEN_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_SOURCE_HEADER_NAME;
import static bank.atb.wind.gateway.support.GatewayUtils.X_SOURCE_HEADER_VALUE_MOBILE;
import static org.springframework.cloud.gateway.support.GatewayToStringStyler.filterToStringCreator;

@Slf4j
@RequiredArgsConstructor
public class BlockNoSessionAccessGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    private final AuthSessionRepository authSessionRepository;

    @Override
    public GatewayFilter apply(Object config) {
        return new GatewayFilter() {
            @Override
            public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
                String sessionId = exchange.getRequest().getHeaders().getFirst(X_AUTH_TOKEN_HEADER_NAME);

                //В фазе начала обработки запроса клиента поверяем наличие активной сессии.
                AuthSession session;
                try {
                    session = authSessionRepository.findBySessionId(sessionId);

                    if (!session.getAuthChannel().equals(AuthChannel.MOBILE)) {
                        log.warn("Канал создания сессии из запроса не совпадают с данными из кэша сессии: sessionId [{}], " +
                                        "authChannel [{}], sessionAuthChannel [{}]",
                                sessionId, AuthChannel.MOBILE, session.getAuthChannel());
                        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);

                        return exchange.getResponse().setComplete();
                    }

                } catch (RuntimeException e) {
                    log.warn("Ошибка при получении сессии из кэша: sessionId [{}]: {}}", sessionId, e.toString());
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                    return exchange.getResponse().setComplete();
                }

                //Удалим авторизационный токен и заголовки с РБО ид и ид аккаунта пришедшие извне
                ServerHttpRequest request = exchange.getRequest()
                        .mutate()
                        .headers(httpHeaders -> {
                            httpHeaders.remove(X_ACCOUNT_ID_HEADER_NAME);
                            httpHeaders.remove(ACCOUNT_ID_HEADER_NAME);
                            httpHeaders.add(X_SOURCE_HEADER_NAME, X_SOURCE_HEADER_VALUE_MOBILE);
                            httpHeaders.add(X_ACCOUNT_ID_HEADER_NAME, session.getRboId());
                        })
                        .build();

                //Сохраним референс учетной записи пользователя для дальнейшего использования.
                exchange.getAttributes().put(GatewayUtils.ACCOUNT_ID_ATTR, session.getAccountId().toString());

                //В фазе завершения обработки запроса клиента продлеваем сессию
                return chain
                        .filter(exchange.mutate().request(request).build())
                        .then(authSessionRepository.extendTimeout(session));
            }

            @Override
            public String toString() {
                return filterToStringCreator(BlockNoSessionAccessGatewayFilterFactory.this).toString();
            }
        };
    }

}
